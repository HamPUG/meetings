import numpy

def funky_array():
    return numpy.array([3,1,4,1,5,9,2,6])

