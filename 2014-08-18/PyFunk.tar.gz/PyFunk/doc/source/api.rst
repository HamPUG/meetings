API
===

blahblahblah.

blahblahblah.


Section 
-------

blahblahblah.

.. code-block:: python

   >>> import numpy
   >>> numpy.array([1,2,3])

