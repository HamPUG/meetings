from setuptools import setup

setup(
    name="PyFunk",
    description="blah",
    long_description=("blahblahblah"),
    url="https://github.com/fracpete/PyFunk",
    classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: GNU General Public License (GPL)',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Programming Language :: Python',
    ],
    license='GNU General Public License version 3.0 (GPLv3)',
    package_dir={
        '': 'src'
    },
    packages=[
        "pyfunk",
    ],
    version="0.1.0",
    author='Peter "fracpete" Reutemann',
    author_email='fracpete at gmail dot com',
    install_requires=[
        "numpy",
    ],
)
