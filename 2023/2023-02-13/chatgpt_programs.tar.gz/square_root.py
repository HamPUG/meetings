#write a python program to find square root of X

# Python program to find the square root of a number 

# importing math library for sqrt() 
import math 

# Input a number 
num = float(input("Enter a number: ")) 

# Calculate the square root of the number 
num_sqrt = math.sqrt(num) 

# Print the number 
print('The square root of %0.3f is %0.3f'%(num ,num_sqrt))



