from django.template import loader

from django.http import HttpResponse

def index(request):
    template = loader.get_template('gallery/hello.html')
    context = {
		'text': "More details on the world"
    }
    return HttpResponse(template.render(context, request))

