# -*- coding: utf-8 -*-

"""
Module implementing MainWindow.
         1         2         3         4         5         6         7        7
1234567890123456789012345678901234567890123456789012345678901234567890123456789
"""

from PyQt4.QtCore import pyqtSlot
from PyQt4.QtGui import QMainWindow

from .Ui_mainwindow import Ui_MainWindow
# Import the math module to provide a value for pi
from math import pi

class MainWindow(QMainWindow, Ui_MainWindow):
    """
    Class documentation goes here.
    """
    def __init__(self, parent=None):
        """
        Constructor
        
        @param parent reference to the parent widget (QWidget)
        """
        super().__init__(parent)
        self.setupUi(self)
    
    @pyqtSlot()
    def on_pushButton_clicked(self):
        """Button click: Obtain Radius, calculate Circumference and Area."""
        
        """
        Check if string is a valid float. 
        If so, calculate and display to two decimal points.
        "{0:.2f}".format(10) = 10.00 <==Python3 syntax  "%0.2f" % 10 <==Python2
        If not, clear the circumference and area display labels
        """
        # Get the radius string from the lineEdit input box.
        radius = self.lineEdit.text()
        
        try:
            # Determine if the radius string is a valid floating point number
            radius = float(radius)
            
            # Calculate Circumference, convert to string and display.
            circumference = "{0:.2f}".format(2 * pi * radius)
            self.label_3.setText(circumference)
            # Calculate Area, convert to string and display.
            area = "{0:.2f}".format(pi * radius **2)        
            self.label_5.setText(area)
            
        except ValueError:
            # Radius string is not a valid float. 
            # Clear the Circumference and Area display labels.
            self.label_3.setText("") 
            self.label_5.setText("")       
            
            
            
